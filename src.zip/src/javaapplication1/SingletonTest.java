/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author kamal
 */
public class SingletonTest {
    private static SingletonTest single_instance = null;
    public String s;
    private SingletonTest(){
        s = "Singleton Class";
    }
    public static SingletonTest getInstance()
    {
        if (single_instance == null)
            single_instance = new SingletonTest();
        return single_instance; 
    }
}
