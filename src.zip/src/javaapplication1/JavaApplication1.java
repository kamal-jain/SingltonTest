/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author kamal
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Thread t1 = new Thread (new Runnable ()
        {
            public run()
            {
                for (int i=0;i<=100;i++)
                {
                    SingletonTest x = SingletonTest.getInstance();
                    
                }
            }
        }
                );
                Thread t2 = new Thread (new Runnable()
                {
                    public run()
                    {
                      for ( int i=0;i<=100;i++)
                      {
                        SingletonTest x = SingletonTest.getInstance();  
                      }
                    }
                }
                        );
                t1.start();
                t2.start();
    }
    
}

